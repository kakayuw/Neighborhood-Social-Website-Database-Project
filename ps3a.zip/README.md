# Problem Set Problem 1 PHP Demo
My submission consists of php code `ps3a.php` which contians backend php code and some front-end javascript code and folder `/ps3a` containing necessary js and css code. This demo shows the problem 1 part, about historical data query about database `weather_station` in assigned in hw2.
***
	
|Student|Net id|student number|Backend| Frontend| Time|
|---|---|---|---|---|---
|Hang Yu|hy1746|N11150159|PHP| jQuery| 11/26/2019

****
## Prerequsite
- php environment

    php version 7.2.18 runs on windows 10 system

- internet connection

    It' s better to run with internet connection because it needs to load javascript and css files from resource server. However completeness of functionality is guaranteed even under the condition of no internet.

- MySQL Server

    MySQL version 5.7.26. Default account is `root` with default password '' (empty). Port `3309` is used for MySQL connection

- Apache Server
    Apache server version is 2.4.39. Default working directory is `/www/app`
----
## Functionality
Visit browser [localhost/app/ps3a.php](localhost/app/ps3a.php).

Input name of city in the left text input box. The date selector in the right side is to filter all measurement data before some given date, i.e. it' s an simulation of "latest" data. Then type the 'query' button and the station information with latest data would be shown in a table. Any row (a station) is clickable, and if clicked another table about all recent measurement would be shown below.

----
## Implementation
All implementation in the code is in the php file `ps3a.php`.

Firstly, MySQL connection is established via php scripts. 

Then prepared SQL statement is created so as to avoid possible SQL injection. 

User first input the name of the city via textbox and php would execute the first SQL script to check if there is station located in the city with the input city name and then whether there have any record before the selected date (default date is `now`). If the date or city name is invalid, the webpage would show an text error result. Otherwise another SQL about latest measurement data would be executed and return the records via a new table.

User then may click on any row of the first table. Then php code would catch the parameter and execute the last SQL about all information about some specific station and return another table as result.

If user intends to change the date filter, he need to click the row agian or click the `query` button again to renew the data.

----

### Relative SQL Scripts

1. Check the validity of city name:
```
    select * from station where scity = ?
```
2. Query the latest data of stations in some city:
```
    select m1.sid, maxt.scity, m1.mtimestamp, m1.mtemp, m1.mhumid, m1.mpriecip
    from measurement m1 join
        (select sid, max(mtimestamp) as maxts, scity
        from measurement m2 natural join station
        where m2.mtimestamp < ?
        group by sid) as maxt     on maxt.sid = m1.sid
    where m1.mtimestamp = maxt.maxts and maxt.scity = ?
```
3. Query all historical data about one station:
```
    select date(mtimestamp) as date, time(mtimestamp) as time, mtemp, mhumid, mpriecip
    from station s natural join measurement m
    where sid = ? and mtimestamp < ?
```