<?php
// global data
$servername = "localhost:3309";
$username = "root";
$password = "";
$dbname = "weather_station";
 
// create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// detect connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// construct SQL scripts
$check_city_sql = "select * from station where scity = ?" ;
$check_city_stmt = $conn->prepare($check_city_sql);
$get_stat_recent_sql = "select m1.sid, maxt.scity, m1.mtimestamp, m1.mtemp, m1.mhumid, m1.mpriecip
  from measurement m1 join
    (select sid, max(mtimestamp) as maxts, scity
      from measurement m2 natural join station
      where m2.mtimestamp < ?
      group by sid) as maxt     on maxt.sid = m1.sid
  where m1.mtimestamp = maxt.maxts and maxt.scity = ?";
$get_stat_recent_stmt = $conn->prepare($get_stat_recent_sql);
$get_stat_his_sql = "select date(mtimestamp) as date, time(mtimestamp) as time, mtemp, mhumid, mpriecip
  from station s natural join measurement m
  where sid = ? and mtimestamp < ?" ;
$get_stat_his_stmt = $conn->prepare($get_stat_his_sql);
?>


<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ps3 problem1</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <link rel="stylesheet" href="ps3a/ps3a.styles.css">
  <script src="ps3a/sorter.js"></script>
  <link href="ps3a/sorter.css" rel="stylesheet">
  <script src="ps3a/pager.js"></script>
  <link href="ps3a/pager.css" rel="stylesheet">
  <script>
  Date.prototype.toDateInputValue = (function() {
      var local = new Date(this);
      local.setMinutes(this.getMinutes() - this.getTimezoneOffset());
      return local.toJSON().slice(0,10);
  });
  $(document).ready(function(){
    if (!$('#mday').val()){    
        document.getElementById('mday').value = new Date().toDateInputValue();
    }
    $('#stat_table tr').click(function() {
        var href = $(this).find("a").attr("href");
        if(href) {
          $.ajax({
            url: "ps3a.php",
            type: "POST",
            data: {sid: href, mday: $("#mday").val()},
            dataType: "html",
            success: function(response){              
              $('#his').html($(response).filter("#his"));
              $('.tablesorter').tablesorter();
              $('.tablepager').tablepager();
            }
          });
        }
    });
    setInterval(function() {
      $('#cityname').text("City: " + $('#stat_table tr:nth-child(2) td:nth-child(2)').text());
      $('#stationid').text("Station: " + $('#stat_his_table tr:nth-child(2) td:nth-child(1)').text());
    }, 100);
  })
  </script>
</head>
<body>


 
<div class="demo">
<form action="" method="POST">
  <section class="container">
  <div class="left">
    <h4>City name:&nbsp;</h4>
    <input type="text"  id="cityinput" name="cityinput"  value="" class="ui-widget ui-state-default ui-corner-all">
    <input  class="ui-button ui-widget ui-state-default ui-corner-all" value="query" type="submit" id="submit"/>
  </div>
  <div class="midleft">
    <h4 id="cityname">City: &nbsp;</h4>
  </div>
  <div class="midright">
    <h4 id="stationid">Station: &nbsp;</h4>
  </div>
  <div class="right">
    <h4>Date before:&nbsp;</h4>
    <input type="date" name="mday" id="mday" class="ui-button ui-widget ui-state-default ui-corner-all">
  </div>
  </section>
</form>

</div>
<div id="stat">
<?php

// catch city request and response
if (!empty( $_POST['cityinput'])){
  $input_city =  $_POST['cityinput'];
  $input_date =  $_POST['mday'];
  $check_city_stmt->bind_param("s", $input_city);
  $check_city_stmt->execute();
  $result = $check_city_stmt->get_result();
  if ($result->num_rows > 0) {
    $get_stat_recent_stmt->bind_param("ss", $input_date, $input_city);
    $get_stat_recent_stmt->execute();
    $result = $get_stat_recent_stmt->get_result();
    if ($result->num_rows > 0) {
      echo "<table id='stat_table'><tr>
      <th>station id</th>
      <th>station city</th>
      <th>latest measurement</th>
      <th>latest temperature</th>
      <th>latest humidity</th>
      <th>latest priecipition</th>
      </tr>";
      while($row = $result->fetch_assoc()) {
          echo "<tr tabindex=". $row['sid']. ">";
          echo "<td>". $row['sid']. "<a href = ". $row['sid']."></a></td>";
          echo "<td>". $row['scity']. "</td>";
          echo "<td>". $row['mtimestamp']. "</td>";
          echo "<td>". $row['mtemp']. "</td>";
          echo "<td>". $row['mhumid']. "</td>";
          echo "<td>". $row['mpriecip']. "</td>";
          echo "</tr>";
      }
      echo "</table>";
    } else {
      echo "No record before ". $input_date;
    }
  } else {
      echo "No record about this city!";
  }
  echo '<script> 
        $("#cityinput").val("'. $input_city.'");
        $("#mday").val("'. $input_date.'");
      </script>';

}
?>
</div>

<div id="his">
<?php

// catch station request and response
if (!empty($_POST['sid'])){
  $sid = $_POST['sid'];
  $input_date =  $_POST['mday'];
  $get_stat_his_stmt->bind_param("ds", $sid, $input_date);
  $get_stat_his_stmt->execute();
  $result = $get_stat_his_stmt->get_result();
  if ($result->num_rows > 0) {
    echo "<table id='stat_his_table' class='tablesorter tablepager'>
    <thead><tr>
    <th>station sid</th>
    <th>measurement date</th>
    <th>measurement time</th>
    <th>measurement temperature</th>
    <th>measurement humidity</th>
    <th>measurement priecipition</th>
    </tr>
    </thead><tbody>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>". $sid. "</td>";
        echo "<td>". $row['date']. "</td>";
        echo "<td>". $row['time']. "</td>";
        echo "<td>". $row['mtemp']. "</td>";
        echo "<td>". $row['mhumid']. "</td>";
        echo "<td>". $row['mpriecip']. "</td>";
    }
    echo "</tbody></table>";
  } else {
      echo "No rows";
  }

}
?>
</div>
 
</body>
</html>


<?php
// close connection
mysqli_close($conn); 
?>